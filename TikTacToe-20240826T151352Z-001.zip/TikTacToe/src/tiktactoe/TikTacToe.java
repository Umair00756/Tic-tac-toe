
package tiktactoe;


public class TikTacToe {

    
    public static void main(String[] args) {
      TTT calculate = new TTT();
         calculate.setVisible(true);
         calculate.pack();
         calculate.setLocationRelativeTo(null);
    }
    
}
